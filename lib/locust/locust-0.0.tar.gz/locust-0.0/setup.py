# encoding: utf8
from setuptools import setup
setup(
    author="Jonatan Heyman",
    author_email="",
    description="Use package locustio instead",
    install_requires=["locustio"],
    long_description="Use `locustio <https://pypi.org/project/locustio/>`_ instead.",
    maintainer="Jonatan Heyman",
    maintainer_email="",
    name="locust",
    platforms=["all"],
    url="https://locust.io",
    version="0.0",
    zip_safe=False,
)
