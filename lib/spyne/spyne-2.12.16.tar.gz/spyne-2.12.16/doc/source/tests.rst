
.. include:: ../../spyne/test/README.rst
