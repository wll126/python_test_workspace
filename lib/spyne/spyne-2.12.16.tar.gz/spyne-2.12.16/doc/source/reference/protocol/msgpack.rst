
.. _reference-protocol-msgpack:

MessagePack
-----------

.. automodule:: spyne.protocol.msgpack
    :members:
    :show-inheritance:

