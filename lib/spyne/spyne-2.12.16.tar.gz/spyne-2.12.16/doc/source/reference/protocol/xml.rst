
.. _reference-protocol-xml:

Xml
---

.. automodule:: spyne.protocol.xml._base
    :members:
    :show-inheritance:
    :undoc-members:
