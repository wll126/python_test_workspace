
.. _reference-server-wsgi:

Http (WSGI)
-----------

.. automodule:: spyne.server.wsgi
    :members:
    :inherited-members:
    :undoc-members:
