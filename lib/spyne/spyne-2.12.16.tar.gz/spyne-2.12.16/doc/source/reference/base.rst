
.. _reference-base:

Fundamental Data Structures
===========================

MethodContext
-------------

.. autoclass:: spyne.MethodContext
    :members:
    :show-inheritance:

MethodDescriptor
----------------

.. autoclass:: spyne.MethodDescriptor
    :members:
    :show-inheritance:

.. _reference-eventmanager:


EventManager
------------

.. autoclass:: spyne.EventManager
    :members:
