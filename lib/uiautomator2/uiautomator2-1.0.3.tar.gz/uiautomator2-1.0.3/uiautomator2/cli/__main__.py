# coding: utf-8
#

from uiautomator2.cli import main

if __name__ == '__main__':
    main()
